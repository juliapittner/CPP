How to run my program:
Once you're on the terminal window type the following: g++ -o shape main.cpp shape.cpp
Then type in shape and the output will appear. 