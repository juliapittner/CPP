#ifndef QUADRILATERAL_H 
#define QUADRILATERAL_H

class Quadrilateral {
    protected:
    double length, height;
};
#endif